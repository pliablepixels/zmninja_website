
<?php
App::uses('AppModel', 'Model');

class Host extends AppModel {

	public $useTable = false;

}
